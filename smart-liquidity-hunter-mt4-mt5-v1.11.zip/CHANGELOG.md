# Release 1.11 - 2026-11-19
First open-source distribution for MT4 and MT5, with code, compiled binaries, screenshots, documentation and MIT license.
